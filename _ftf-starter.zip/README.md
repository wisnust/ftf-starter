# FTF Starter Wordpress Theme

## Getting Started

Navigate to **_ftf-starter.zip**

Go to admin dashboard > upload the theme


### Development

Install Node Modules

```
$ npm install
```

Run Gulp for SCSS Compiler and Minified Javascript

```
$ gulp build
```

### Adding Plugins

Install **ACF Plugin** and **ACF Option Plugin**

Then go to admin dashboard

**Custom Fields** > **Sync** > (Check mark) select all > bulk action > **Sync All**