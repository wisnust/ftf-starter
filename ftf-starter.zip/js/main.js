jQuery(document).ready(function($) {
	$('.test').addClass('testtt')
});